from flask import Flask, jsonify, request
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS for all routes

lobbies = {}  # {lobby_code: [student_ids]}
students = {}  # {student_id: {"name": str, "lobby": str, "status": str}}

@app.route('/create_lobby', methods=['POST'])
def create_lobby():
    try:
        code = ''.join(random.choices('0123456789', k=6))
        while code in lobbies:
            code = ''.join(random.choices('0123456789', k=6))
        lobbies[code] = []
        return jsonify({"lobby_code": code}), 200
    except Exception as e:
        return jsonify({"error": f"Failed to create lobby: {str(e)}"}), 500

@app.route('/get_lobby/<code>', methods=['GET'])
def get_lobby(code):
    try:
        if code in lobbies:
            student_info = [
                {"id": student, "name": students[student]["name"], "status": students[student]["status"]}
                for student in lobbies[code]
            ]
            return jsonify(student_info), 200
        else:
            return jsonify({"error": "Lobby not found"}), 404
    except Exception as e:
        return jsonify({"error": f"Failed to fetch lobby: {str(e)}"}), 500

@app.route('/join_lobby', methods=['POST'])
def join_lobby():
    try:
        data = request.json
        code = data.get('code')
        name = data.get('name')

        if not code or not name:
            return jsonify({"error": "Lobby code and name are required"}), 400

        if code in lobbies:
            student_id = f"ID-{random.randint(10000, 99999)}"
            students[student_id] = {"name": name, "lobby": code, "status": "active"}
            lobbies[code].append(student_id)
            return jsonify({"student_id": student_id, "name": name, "lobby": code}), 200
        else:
            return jsonify({"error": "Lobby not found"}), 404
    except Exception as e:
        return jsonify({"error": f"Failed to join lobby: {str(e)}"}), 500

@app.route('/kick_student/<student_id>', methods=['POST'])
def kick_student(student_id):
    try:
        if student_id in students:
            lobby = students[student_id]["lobby"]
            lobbies[lobby].remove(student_id)
            del students[student_id]
            return jsonify({"message": f"Student {student_id} removed from lobby {lobby}"}), 200
        else:
            return jsonify({"error": "Student not found"}), 404
    except Exception as e:
        return jsonify({"error": f"Failed to kick student: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)